package com.repforge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.repforge.app.data.db.TrainPilotDatabase
import com.repforge.app.data.migration.LegacyWebViewMigrator
import com.repforge.app.data.store.TrainPilotSettingsStore
import com.repforge.app.ui.navigation.TrainPilotAppScaffold
import com.repforge.app.ui.theme.TrainPilotTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

import androidx.activity.viewModels
import com.example.TrainPilotAppRoot
import com.example.ui.theme.TrainPilotPalettes
import com.example.ui.viewmodel.TrainPilotViewModel

class MainActivity : ComponentActivity() {
    private lateinit var startupScreen: StartupScreen
    private lateinit var settingsStore: TrainPilotSettingsStore
    private lateinit var database: TrainPilotDatabase
    private lateinit var migrator: LegacyWebViewMigrator
    private val viewModel: TrainPilotViewModel by viewModels()
    private var recoveryNeeded by mutableStateOf(false)
    private var recoveryBusy by mutableStateOf(false)
    private var recoveryError by mutableStateOf(false)
    private var migrationReady by mutableStateOf(false)
    private var migrationFailure by mutableStateOf(false)
    private var migrationJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        startupScreen = StartupScreen.install(this)
        super.onCreate(savedInstanceState)
        // All native palettes use dark surfaces, independently of Android's day/night mode.
        // Auto system-bar styling otherwise puts dark clock/icons on the dark app background.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        settingsStore = TrainPilotSettingsStore(this)
        database = TrainPilotDatabase.getInstance(this)
        migrator = LegacyWebViewMigrator(this, database, settingsStore)

        recoveryNeeded = NativeDataReplacement.blocked(this) || NativeReplacementJournal(this).exists() || PhoneWorkoutExecution.store(this).restoreBlocked()
        startMigration()

        setContent {
            val settings by settingsStore.settingsFlow.collectAsStateWithLifecycle(
                initialValue = com.repforge.app.data.store.TrainPilotUserSettings()
            )

            LaunchedEffect(settings) {
                viewModel.syncNativeSettings(
                    languageCode = settings.language,
                    themeKey = settings.themeKey,
                    restSec = settings.restSeconds,
                    sound = settings.soundEnabled,
                    vibration = settings.vibrationEnabled
                )
            }

            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val currentPalette = TrainPilotPalettes.getById(uiState.selectedPaletteId)

            com.example.ui.theme.TrainPilotTheme(
                palette = currentPalette,
                fontScaleMultiplier = uiState.fontScaleMultiplier
            ) {
                if (recoveryNeeded) {
                    LaunchedEffect(Unit) { startupScreen.markNativeReady() }
                    com.repforge.app.ui.settings.ReplacementRecoveryPanel(
                        settings.language,
                        recoveryBusy,
                        recoveryError,
                        onResume = { recoverReplacement() },
                        onJson = { recoverReplacement(it, false) },
                        onZip = { recoverReplacement(it, true) }
                    )
                } else {
                    LaunchedEffect(Unit) {
                        startupScreen.markNativeReady()
                    }
                    TrainPilotAppRoot(viewModel = viewModel)
                }
            }
        }
        startupScreen.attach()
    }

    private fun startMigration() {
        if (recoveryNeeded || migrationJob?.isActive == true || migrationReady) return
        migrationFailure = false
        migrationJob = lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { migrator.migrateIfNeeded() }
                migrationReady = true
                withContext(Dispatchers.IO) {
                    try { HealthBackgroundService.resume(this@MainActivity) } catch (_: Throwable) {}
                    try { HealthBackgroundJob.schedule(this@MainActivity) } catch (_: Throwable) {}
                    try { WearSyncRepository.publishWatchHomeSnapshot(this@MainActivity) } catch (_: Throwable) {}
                }
            } catch (cancelled: CancellationException) { throw cancelled }
            catch (e: Exception) {
                android.util.Log.e("MainActivity", "Startup migration failed", e)
                migrationFailure = true
            }
        }
    }

    private fun recoverReplacement(uri: android.net.Uri? = null, zip: Boolean = false) {
        if (recoveryBusy) return
        recoveryBusy = true
        lifecycleScope.launch {
            try {
                val manager = BackupRestoreManager(this@MainActivity)
                val result = when { uri == null -> manager.resumeInterruptedReplacement()
                    zip -> manager.importZipArchiveFromUri(uri, recoverInterrupted = true)
                    else -> manager.importJsonBackupFromUri(uri, recoverInterrupted = true) }
                recoveryError = result.isFailure
                if (result.isSuccess) { recoveryNeeded = false; startMigration() }
            } finally { recoveryBusy = false }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!migrationReady) return
        HealthBackgroundService.stop(this)
        lifecycleScope.launch(Dispatchers.IO) {
            try { HealthJournalStore.get(this@MainActivity).retireWatchUi() } catch (_: Exception) {}
            try { HealthBackgroundJob.schedule(this@MainActivity) } catch (_: Exception) {}
            WearSyncRepository.publishWatchHomeSnapshot(this@MainActivity)
        }
    }

    override fun onDestroy() {
        startupScreen.destroy()
        super.onDestroy()
    }
}
