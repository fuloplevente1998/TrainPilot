# Automatikus intervallumléptetés (#162)

## Telefonos folytatás — 1.3.4

A #179-ben mainre integrált első tesztváltozatban a folyamatban levő tervezett vagy gyors edzés **Automata mód** kapcsolója engedélyezi a kézi rögzítés utáni automatikus pihenő-/gyakorlatléptetést. A választás elmenthető. Az ismétlést és súlyt továbbra is a felhasználó rögzíti; a pihenő nem ír kitalált sorozatot.

A felhasználó kérése szerint az aktív visszaszámláló manuális és automata módban is a meglévő alsó vezérlősávban, **az Előző és Következő gomb között** marad. Az Automata mód kis, másodlagos kapcsoló fölöttük, az Előző/Következő gombokhoz képest kisebb. Az automatikus pihenő szünet-/kihagyás vezérlése is kompakt; a fő tartalom fölé nem kerül nagy automata kártya.

- Ismétléses gyakorlat: Rögzítés → a gyakorlat/program szerinti pihenő → következő befejezetlen sorozat/gyakorlat. A pihenő szüneteltethető, folytatható és kihagyható. Az utolsó sorozat után nincs felesleges pihenő vagy automatikus végső mentés.
- Súlyzós → időzített átmenet: a következő időalapú sorozat menetrendje az előző gyakorlat pihenőjével indul, majd automatikusan munkára vált. A kezdő pihenő nem növeli a sorozat mért munkaidejét.
- Az önálló ismétléses pihenő is ugyanazt a natív Android foreground időzítőt használja. Lezárt telefon mellett a szolgáltatás időzít és jelez; az előkészített következő sorozatot a felület visszatéréskor ugyanahhoz az azonosítóhoz illeszti. A készre jelölés kézi marad.
- Az Android értesítésből Szünet/Folytatás és Leállítás érhető el. A GPS tervezett pihenőben és kézi szünetben is szünetel; munkára visszatérve új horgonyt vesz fel.
- Bekapcsolt rezgésnél a natív automata/intervallum-visszaszámlálás utolsó 3 másodpercében másodpercenként egy 80 ms-os rövid impulzus jelez. Szakaszváltáskor és lejáratkor egy 1 másodperces, egybefüggő rezgés következik. Szünet vagy leállítás megszakítja a rezgést; folytatás és ismételt állapotlekérés nem ismétli meg a már jelzett másodpercet. Rövid szakasznál csak a rendelkezésre álló előjelzések szólalnak meg, és nem vágják félbe az előző hosszú jelzést. A böngészős tartalék működés ugyanezt a mintát használja, amíg az oldal meg van nyitva.
- Visszapipálás, kézi léptetés, sorozattörlés, új edzés és későn visszatérő natív válasz nem rögzíthet másik edzésbe. Megszakadt szolgáltatásból nincs kitalált folytatás.
- A korábban átadott Wear-kezdőlap témaszinkronja megmarad a telefonos home snapshotban.

A #179 a telefonos alaphoz órás natív automata tesztváltozatot is integrál a main fejlesztési alapjába. Órán indított edzésnél az óra vezérli az időzítést, a telefon távoli vezérlő és megjelenítő; telefonos indításnál a telefon marad a tulajdonos. Az első integráció működése, telepítése és még hátralévő korlátai a közös tervben vannak: [WEAR_OS_FEJLESZTESI_TERV.md](wear/WEAR_OS_FEJLESZTESI_TERV.md).

## Időzített sorozatok

Az edzés időalapú gyakorlatán az **Intervallumidőzítő** lenyitható kártyájában adható meg a munka, pihenő és körszám; a hang és rezgés külön kapcsolható. A mentett beállítás tartalmazza az automatikus léptetés kapcsolóját is.

- Alapállapotban az intervallum egy sorozatot mér, és nem jelöli késznek.
- Automatikus módban a jelenlegi és következő időalapú sorozatokra ugyanez az intervallum érvényes. A sorozatok között a megadott pihenő is szerepel, az utolsó után nincs külön pihenő. A sorozat mért ideje a munka és pihenő együttese.
- Ismétlésszámos vagy oldalanként mért gyakorlatnál az időalapú menetrend megáll. A felhasználó ténylegesen rögzíti a sorozatot; a teljes edzés Automata mód kapcsolójával az ezt követő pihenő tovább léptet. Nem ír ismétlést vagy súlyt, nem ugrik át egy erősítő gyakorlatot, és nem menti el automatikusan az edzést.
- Korábban beírt idő/távolság megmarad, az új mérés hozzáadódik.
- Szünet / folytatás a kártya óráján. A Leállítás megtartja az addigi mérést; új intervallum ezután indítható.

## Telefon és GPS

A felhasználó által, megnyitott alkalmazásban indított `IntervalTimerService` véges, monotón idővonalat futtat. A kijelző lezárásától független hang/rezgés és leállítható értesítés tartozik hozzá. A `specialUse` foreground service és a futás alatti, időkorlátos partial wake lock kifejezetten erre szolgál; szünetben és befejezéskor elengedi a wake lockot. Nincs bootból újraindítás vagy pontos-riasztás engedélykérés. A Play Console foreground-service deklarációjához a manifestben szerepel a konkrét fitneszidőzítő felhasználás.

A GPS külön elindítható az intervallum előtt vagy közben. Automatikus, egymást követő távolsági sorozatoknál a meglévő helymeghatározási szolgáltatás marad életben, csak az adat tulajdonosa vált. Minden szakasz idő/távolság adata a stabil sorozatazonosítóhoz kerül. Nincs új háttérből indított location service. Szünetben a GPS sem mér, folytatáskor új koordináta-horgonyt vesz fel, hogy a szünet alatti elmozdulást ne számolja be.

Piszkozatból a szolgáltatás ugyanazon azonosítóihoz csatlakozik vissza. Ha az Android megszakította a folyamatot, szünetelt/megszakadt állapotot mutat; nem állítja késznek a kimaradt időt. Az értesítés Leállítás gombja az adott időzítő azonosítójára érvényes. A GPS-szolgáltatás is csak a saját elvárt mérési kulcsával állítható le vagy váltható át.

Böngészőben a manuális időzítő kompatibilis marad; automatikus módban az oldalt nyitva kell tartani. Újratöltés után a böngészős program megszakad, nem folytatódik észrevétlenül.

## Egységes időnapló — #162 P0 folytatás

A `session.automaticTime162` új, külön időnapló. A `logs` gyűjtemény kulcsa a konkrét telefonos, órás vagy böngészős idővonal azonosítója; egy újabb snapshot ugyanazt a hozzájárulást frissíti. A `workMs`, `restMs`, `pausedMs` külön érték, milliszekundumban. Ismételt kézbesítés nem számolja kétszer az időt, kihagyott pihenő nem növeli a mért pihenőt. Az összesítő nem a korábbi sorozat-`reps` mezőt adja hozzá az időnaplóhoz.

A telefonos foreground szolgáltatás a munkát/pihenőt monotón órából méri, a kézi szünetet külön számolja. Az elkészült időalapú sorozat, az időnapló és a tartós importesemény egy tranzakcióban mentődik. A felület visszatérésekor a mentett snapshotból dolgozik, és csak a piszkozat + eseménykurzor mentése után nyugtáz. Folyamatmegszakadás után nincs ismeretlen idő utólagos hozzászámítása vagy rezgés-visszajátszás.

Az önálló órás automata exportálja ugyanezt a formát. A korábbi Wear-szabály megmarad: késői callbacknél legfeljebb egy fázist léptet, a nem igazolt további köröket nem írja késznek. A telefon a készüléktulajdonoshoz tartozó adatot menti, az eltérő készülékek méréseit nem összeadott másolatként kezeli.

A támogatott telefonos kézi, ismétléses rögzítés is a natív útvonalat használja. A javítás/visszavonás explicit, revízióval és előző értékekkel ellenőrzött művelet; elavult snapshot nem írja felül a kész sorozatot. A távolsági/GPS-tulajdonos további előkészítése külön marad.

## Ellenőrzés

- Node: fázishatárok, nulla pihenő, sorozatok közti pihenő, késői callback, 24 órás / 100 sorozatos korlát, duplikált gyakorlat mellett stabil tulajdonos.
- JVM: ugyanazon idővonal határesetei; GPS-horgony visszaállítása szünet után.
- Böngésző: 32 telefonméret/nyelv/téma kombináció; mentett kapcsoló; automatikus sorozat/gyakorlatváltás; GPS-szakaszok, szünet/folytatás; piszkozat; dupla indítás és későn visszatérő bridge-válasz; kézi végső mentés. A natív bridge válaszait itt tesztadapter adja.
- Teljes meglévő release gate és Android/JVM build a PR-ágon.

Fizikai telefonos elfogadási ellenőrzés még szükséges: hang + rezgés lezárt kijelzővel; GPS és intervallum együtt, szünet/folytatás; értesítésből leállítás; app bezárása és visszaállítás. A CI nem bizonyít OEM akkumulátorkezelést vagy tényleges GPS-pontosságot.

A verzió az elfogadott main szerinti 1.3.4 / 2730; a tesztbuild a forráscommit alapján azonosítható. A térképes útvonalnapló külön #163 feladat, ez a változtatás nem tárol útvonalkoordinátákat.
