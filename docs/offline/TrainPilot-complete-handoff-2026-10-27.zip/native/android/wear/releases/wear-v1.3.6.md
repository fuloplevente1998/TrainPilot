# TrainPilot Wear OS 1.3.6

Telefon és Wear OS: **1.3.6 /2733**. A verzióemelést és a #216 csomag lezárását a felhasználó 2026-10-19-én jóváhagyta. A végleges APK-kat az aláírt GitHub Actions kapuk állítják elő; a kiadási workflow csak saját sikeres ellenőrzései után publikál.

- Önálló órás edzés, visszaigazolt telefon–óra átadás és offline folytatás; az órán rögzített privát GPS-útvonal a telefon naplójában is megtekinthető.
- Telefonos GPS-mérés kifejezett, sikeres befejezése külön sorozat-OK nélkül elfogadja a mért időt és távolságot.
- Kompaktabb telefonos Intervallumok felület, sima és oldalsó planknél is.
- Órás súly-/ismétlés-/időszerkesztés korona vagy lünetta használatával; a Mentés/Mégse megmarad.
- Átrendezett órás menü: aktív edzés és Gyors edzés elöl, Naptár és Programnapok közös Tervezett edzések csoportban.
- Új kültéri edzés előtt látható, aktivitásonként megjegyzett GPS-választás; a futó edzésen közvetlen GPS-állapot és kezelés. Újracsatlakozás önmagában nem indít rögzítést.
- Gyakorlatváltás után az órán is megmarad a pihenő visszaszámlálása az eredeti határidővel.
- Korábban elfogadott visszavonás, folyamatos 3 másodperces feloldás, nyelvi és szenzorstabilitási javítások megőrizve.

Frissítéskor mindkét APK telepítendő; a korábbi telepítésre, a meglévő aláíróval. Az óra GPS-rögzítése és a telefonos térkép eltérő szerep: az órán nincs térképrajzoló felület. A pontos helyengedély és az óra központi helyszolgáltatása külön feltétel.

A #206 maradék aktivitásnézete, #197 progressziós módjai, #184 Samsung Energy Score és #214 karbantartás külön backlog; ez a kiadás nem állítja ezeket késznek.
